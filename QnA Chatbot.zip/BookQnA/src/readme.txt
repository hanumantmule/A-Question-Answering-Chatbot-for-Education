Install dependencies
    pip install -r requirements.txt

Run the application
    flask run

Open browser
    Go to http://127.0.0.1:5000.